# 🚀 Quick Start: Install Gateway

> Gateway is an agent sidecar service. Deploy it on the same machine as your AI agent.

## Install

```bash
npm install -g https://github.com/zhou12138/cli-server/raw/master/downloads/landgod-gateway-0.1.0.tgz
```

Or Python version:
```bash
pip install https://github.com/zhou12138/cli-server/raw/master/downloads/landgod_gateway_server-0.1.0-py3-none-any.whl
```

## Start

```bash
# Node.js (background)
landgod-gateway start --daemon --token YOUR_SECRET_TOKEN

# Node.js (foreground, for debugging)
landgod-gateway start --token YOUR_SECRET_TOKEN

# Python
landgod-gateway-py start --token YOUR_SECRET_TOKEN
```

> ⚠️ `--token` is **required**. Gateway will not start without it.

## Verify

```bash
landgod-gateway status
curl -s http://localhost:8081/health
```

Expected:
```json
{"status":"ok","connectedClients":0}
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Health check |
| GET | `/clients` | List connected workers |
| GET | `/tools` | List tools per worker |
| POST | `/tool_call` | Execute command on a worker |
| POST | `/batch_tool_call` | Parallel execution on multiple workers |
| GET | `/audit` | Centralized audit logs |
| GET | `/tasks` | List async/queued tasks |
| GET | `/tasks/:id` | Get task status and result |

## Ports

| Port | Protocol | Used By |
|------|----------|---------|
| 8081 | HTTP | Agent requests |
| 8080 | WebSocket | Worker connections |

## Auto-start (optional)

```bash
# Linux systemd
sudo tee /etc/systemd/system/landgod-gateway.service > /dev/null << 'EOF'
[Unit]
Description=LandGod Gateway
After=network.target
[Service]
Type=simple
User=YOUR_USER
Environment=LANDGOD_AUTH_TOKEN=YOUR_SECRET_TOKEN
ExecStart=landgod-gateway start
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload && sudo systemctl enable --now landgod-gateway
```

## Next

→ [Install Worker](./QUICKSTART-WORKER.md)
