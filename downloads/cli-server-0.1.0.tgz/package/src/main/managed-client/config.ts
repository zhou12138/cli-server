import * as os from 'node:os';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { randomUUID } from 'node:crypto';
import type { ManagedClientMode, ManagedClientRuntimeConfig } from './types';
import { getDefaultManagedClientWorkspaceRoot } from './workspace';
import { parseManagedClientMcpServers, type ManagedClientFileMcpServerConfig } from './mcp-server-config';
import {
  applyPermissionProfileGuards,
  DEFAULT_BUILT_IN_TOOLS_SECURITY_CONFIG,
  getBuiltInToolsSecurityConfigForProfile,
  normalizeBuiltInToolsPermissionProfile,
  type BuiltInToolsSecurityConfig,
  type BuiltInToolsPermissionProfile,
} from '../builtin-tools/types';

export type ToolCallApprovalMode = 'auto' | 'manual';

interface ManagedClientFileConfig {
  mode?: ManagedClientMode;
  bootstrapBaseUrl?: string;
  baseUrl?: string;
  signinPageUrl?: string;
  tlsServername?: string;
  workspaceRoot?: string;
  token?: string;
  clientId?: string;
  clientName?: string;
  pollWaitSeconds?: number;
  retryDelayMs?: number;
  enabled?: boolean;
  mcpServers?: Record<string, ManagedClientFileMcpServerConfig>;
  builtInTools?: PartialBuiltInToolsSecurityConfig;
  toolCallApprovalMode?: ToolCallApprovalMode;
}

type PartialBuiltInToolsSecurityConfig = {
  permissionProfile?: BuiltInToolsPermissionProfile;
  shellExecute?: Partial<BuiltInToolsSecurityConfig['shellExecute']>;
  fileRead?: Partial<BuiltInToolsSecurityConfig['fileRead']>;
  managedMcpServerAdmin?: Partial<BuiltInToolsSecurityConfig['managedMcpServerAdmin']>;
};

interface PersistedManagedClientMcpServerConfig extends ManagedClientFileMcpServerConfig {
  name?: string;
}

function getManagedClientConfigPath(): string {
  return path.resolve(process.cwd(), 'managed-client.config.json');
}

function getManagedClientMcpConfigPath(): string {
  return path.resolve(process.cwd(), 'managed-client.mcp-servers.json');
}

function normalizeManagedClientMcpServers(
  parsed: unknown,
): Record<string, ManagedClientFileMcpServerConfig> {
  if (!parsed) {
    return {};
  }

  if (Array.isArray(parsed)) {
    return Object.fromEntries(
      parsed.flatMap((entry): Array<[string, ManagedClientFileMcpServerConfig]> => {
        if (!entry || typeof entry !== 'object') {
          return [];
        }

        const { name, ...config } = entry as PersistedManagedClientMcpServerConfig;
        if (typeof name !== 'string' || !name.trim()) {
          return [];
        }

        return [[name.trim(), config]];
      }),
    );
  }

  if (typeof parsed === 'object') {
    return parsed as Record<string, ManagedClientFileMcpServerConfig>;
  }

  return {};
}

function parseStringList(value: unknown): string[] {
  if (!Array.isArray(value)) {
    return [];
  }

  return value
    .filter((entry): entry is string => typeof entry === 'string')
    .map((entry) => entry.trim())
    .filter(Boolean);
}

function parsePositiveNumber(value: unknown, fallback: number): number {
  const parsed = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function parseBooleanValue(value: unknown, fallback: boolean): boolean {
  return typeof value === 'boolean' ? value : fallback;
}

function getChangedEntries<T extends object>(base: T, value: T): Partial<T> | undefined {
  const changedEntries = Object.entries(value).filter(([key, currentValue]) => base[key as keyof T] !== currentValue);
  if (changedEntries.length === 0) {
    return undefined;
  }

  return Object.fromEntries(changedEntries) as Partial<T>;
}

function serializeBuiltInToolsSecurityConfig(config: BuiltInToolsSecurityConfig): PartialBuiltInToolsSecurityConfig {
  const normalized = applyPermissionProfileGuards(config);
  const base = getBuiltInToolsSecurityConfigForProfile(normalized.permissionProfile);

  return {
    permissionProfile: normalized.permissionProfile,
    shellExecute: getChangedEntries(base.shellExecute, normalized.shellExecute),
    fileRead: getChangedEntries(base.fileRead, normalized.fileRead),
    managedMcpServerAdmin: {
      enabled: normalized.managedMcpServerAdmin.enabled,
      allowHttpServers: normalized.managedMcpServerAdmin.allowHttpServers,
      allowStdioServers: normalized.managedMcpServerAdmin.allowStdioServers,
      sandboxStdioServers: normalized.managedMcpServerAdmin.sandboxStdioServers,
      allowedStdioServerCommands: normalized.managedMcpServerAdmin.allowedStdioServerCommands,
    },
  };
}

function normalizeBuiltInToolsSecurityConfig(parsed: unknown): BuiltInToolsSecurityConfig {
  const permissionProfile = normalizeBuiltInToolsPermissionProfile(
    typeof parsed === 'object' && parsed !== null && 'permissionProfile' in parsed
      ? (parsed as { permissionProfile?: unknown }).permissionProfile
      : undefined,
  );
  const defaults = getBuiltInToolsSecurityConfigForProfile(permissionProfile);
  const shellExecute = typeof parsed === 'object' && parsed !== null && 'shellExecute' in parsed
    ? (parsed as { shellExecute?: unknown }).shellExecute
    : undefined;
  const fileRead = typeof parsed === 'object' && parsed !== null && 'fileRead' in parsed
    ? (parsed as { fileRead?: unknown }).fileRead
    : undefined;
  const managedMcpServerAdmin = typeof parsed === 'object' && parsed !== null && 'managedMcpServerAdmin' in parsed
    ? (parsed as { managedMcpServerAdmin?: unknown }).managedMcpServerAdmin
    : undefined;

  return applyPermissionProfileGuards({
    permissionProfile,
    shellExecute: {
      enabled: parseBooleanValue(
        typeof shellExecute === 'object' && shellExecute !== null ? (shellExecute as { enabled?: unknown }).enabled : undefined,
        defaults.shellExecute.enabled,
      ),
      allowedExecutableNames: parseStringList(
        typeof shellExecute === 'object' && shellExecute !== null ? (shellExecute as { allowedExecutableNames?: unknown }).allowedExecutableNames : undefined,
      ),
      allowedWorkingDirectories: parseStringList(
        typeof shellExecute === 'object' && shellExecute !== null ? (shellExecute as { allowedWorkingDirectories?: unknown }).allowedWorkingDirectories : undefined,
      ),
      allowPipes: typeof shellExecute === 'object' && shellExecute !== null && 'allowPipes' in shellExecute
        ? parseBooleanValue((shellExecute as { allowPipes?: unknown }).allowPipes, defaults.shellExecute.allowPipes)
        : !parseBooleanValue(
          typeof shellExecute === 'object' && shellExecute !== null ? (shellExecute as { blockPipes?: unknown }).blockPipes : undefined,
          !defaults.shellExecute.allowPipes,
        ),
      allowRedirection: typeof shellExecute === 'object' && shellExecute !== null && 'allowRedirection' in shellExecute
        ? parseBooleanValue((shellExecute as { allowRedirection?: unknown }).allowRedirection, defaults.shellExecute.allowRedirection)
        : !parseBooleanValue(
          typeof shellExecute === 'object' && shellExecute !== null ? (shellExecute as { blockRedirection?: unknown }).blockRedirection : undefined,
          !defaults.shellExecute.allowRedirection,
        ),
      allowNetworkCommands: typeof shellExecute === 'object' && shellExecute !== null && 'allowNetworkCommands' in shellExecute
        ? parseBooleanValue((shellExecute as { allowNetworkCommands?: unknown }).allowNetworkCommands, defaults.shellExecute.allowNetworkCommands)
        : !parseBooleanValue(
          typeof shellExecute === 'object' && shellExecute !== null ? (shellExecute as { blockNetworkCommands?: unknown }).blockNetworkCommands : undefined,
          !defaults.shellExecute.allowNetworkCommands,
        ),
      allowInlineScripts: parseBooleanValue(
        typeof shellExecute === 'object' && shellExecute !== null ? (shellExecute as { allowInlineScripts?: unknown }).allowInlineScripts : undefined,
        defaults.shellExecute.allowInlineScripts,
      ),
      allowPathsOutsideWorkspace: parseBooleanValue(
        typeof shellExecute === 'object' && shellExecute !== null ? (shellExecute as { allowPathsOutsideWorkspace?: unknown }).allowPathsOutsideWorkspace : undefined,
        defaults.shellExecute.allowPathsOutsideWorkspace,
      ),
      sandboxExecution: parseBooleanValue(
        typeof shellExecute === 'object' && shellExecute !== null ? (shellExecute as { sandboxExecution?: unknown }).sandboxExecution : undefined,
        defaults.shellExecute.sandboxExecution,
      ),
      maxCommandLength: parsePositiveNumber(
        typeof shellExecute === 'object' && shellExecute !== null ? (shellExecute as { maxCommandLength?: unknown }).maxCommandLength : undefined,
        defaults.shellExecute.maxCommandLength,
      ),
      maxTimeoutSeconds: parsePositiveNumber(
        typeof shellExecute === 'object' && shellExecute !== null ? (shellExecute as { maxTimeoutSeconds?: unknown }).maxTimeoutSeconds : undefined,
        defaults.shellExecute.maxTimeoutSeconds,
      ),
    },
    fileRead: {
      enabled: parseBooleanValue(
        typeof fileRead === 'object' && fileRead !== null ? (fileRead as { enabled?: unknown }).enabled : undefined,
        defaults.fileRead.enabled,
      ),
      allowRelativePaths: parseBooleanValue(
        typeof fileRead === 'object' && fileRead !== null ? (fileRead as { allowRelativePaths?: unknown }).allowRelativePaths : undefined,
        defaults.fileRead.allowRelativePaths,
      ),
      allowedPaths: parseStringList(
        typeof fileRead === 'object' && fileRead !== null ? (fileRead as { allowedPaths?: unknown }).allowedPaths : undefined,
      ),
      maxBytesPerRead: parsePositiveNumber(
        typeof fileRead === 'object' && fileRead !== null ? (fileRead as { maxBytesPerRead?: unknown }).maxBytesPerRead : undefined,
        defaults.fileRead.maxBytesPerRead,
      ),
      maxFileSizeBytes: parsePositiveNumber(
        typeof fileRead === 'object' && fileRead !== null ? (fileRead as { maxFileSizeBytes?: unknown }).maxFileSizeBytes : undefined,
        defaults.fileRead.maxFileSizeBytes,
      ),
    },
    managedMcpServerAdmin: {
      enabled: parseBooleanValue(
        typeof managedMcpServerAdmin === 'object' && managedMcpServerAdmin !== null ? (managedMcpServerAdmin as { enabled?: unknown }).enabled : undefined,
        defaults.managedMcpServerAdmin.enabled,
      ),
      allowHttpServers: parseBooleanValue(
        typeof managedMcpServerAdmin === 'object' && managedMcpServerAdmin !== null ? (managedMcpServerAdmin as { allowHttpServers?: unknown }).allowHttpServers : undefined,
        defaults.managedMcpServerAdmin.allowHttpServers,
      ),
      allowStdioServers: parseBooleanValue(
        typeof managedMcpServerAdmin === 'object' && managedMcpServerAdmin !== null ? (managedMcpServerAdmin as { allowStdioServers?: unknown }).allowStdioServers : undefined,
        defaults.managedMcpServerAdmin.allowStdioServers,
      ),
      sandboxStdioServers: parseBooleanValue(
        typeof managedMcpServerAdmin === 'object' && managedMcpServerAdmin !== null ? (managedMcpServerAdmin as { sandboxStdioServers?: unknown }).sandboxStdioServers : undefined,
        defaults.managedMcpServerAdmin.sandboxStdioServers,
      ),
      allowedStdioServerCommands: parseStringList(
        typeof managedMcpServerAdmin === 'object' && managedMcpServerAdmin !== null ? (managedMcpServerAdmin as { allowedStdioServerCommands?: unknown }).allowedStdioServerCommands : undefined,
      ),
    },
  });
}

export function loadManagedClientFileConfig(): ManagedClientFileConfig {
  const configPath = getManagedClientConfigPath();
  if (!fs.existsSync(configPath)) {
    return {};
  }

  const raw = fs.readFileSync(configPath, 'utf-8');
  const parsed = JSON.parse(raw) as ManagedClientFileConfig;
  return parsed ?? {};
}

export function saveManagedClientFileConfig(config: ManagedClientFileConfig): void {
  const current = loadManagedClientFileConfig();
  const next = {
    ...current,
    ...config,
  };

  const sanitized = Object.fromEntries(
    Object.entries(next).filter(([, value]) => value !== undefined),
  );

  fs.writeFileSync(getManagedClientConfigPath(), JSON.stringify(sanitized, null, 2), 'utf-8');
}

export function getBuiltInToolsSecurityConfig(): BuiltInToolsSecurityConfig {
  return normalizeBuiltInToolsSecurityConfig(loadManagedClientFileConfig().builtInTools);
}

export function saveBuiltInToolsSecurityConfig(config: BuiltInToolsSecurityConfig): void {
  saveManagedClientFileConfig({
    builtInTools: serializeBuiltInToolsSecurityConfig(normalizeBuiltInToolsSecurityConfig(config)),
  });
}

export function getToolCallApprovalMode(): ToolCallApprovalMode {
  return loadManagedClientFileConfig().toolCallApprovalMode ?? 'manual';
}

export function setToolCallApprovalMode(mode: ToolCallApprovalMode): void {
  saveManagedClientFileConfig({ toolCallApprovalMode: mode });
}

function loadManagedClientMcpFileConfig(): Record<string, ManagedClientFileMcpServerConfig> {
  const configPath = getManagedClientMcpConfigPath();
  if (fs.existsSync(configPath)) {
    const raw = fs.readFileSync(configPath, 'utf-8');
    const parsed = JSON.parse(raw) as unknown;
    return normalizeManagedClientMcpServers(parsed);
  }

  return loadManagedClientFileConfig().mcpServers ?? {};
}

function saveManagedClientMcpFileConfig(mcpServers: Record<string, ManagedClientFileMcpServerConfig>): void {
  fs.writeFileSync(
    getManagedClientMcpConfigPath(),
    JSON.stringify(mcpServers, null, 2),
    'utf-8',
  );
}

function removeLegacyManagedClientMcpServersConfig(): void {
  const current = loadManagedClientFileConfig();
  if (!('mcpServers' in current)) {
    return;
  }

  const { mcpServers: _legacyMcpServers, ...rest } = current;
  const next = Object.fromEntries(
    Object.entries(rest).filter(([, value]) => value !== undefined),
  );

  fs.writeFileSync(getManagedClientConfigPath(), JSON.stringify(next, null, 2), 'utf-8');
}

export function getManagedClientMcpServersConfig(): Record<string, ManagedClientFileMcpServerConfig> {
  return loadManagedClientMcpFileConfig();
}

export function saveManagedClientMcpServersConfig(mcpServers: Record<string, ManagedClientFileMcpServerConfig>): void {
  saveManagedClientMcpFileConfig(mcpServers);
  removeLegacyManagedClientMcpServersConfig();
}

function parseBooleanFlag(value: string | undefined): boolean {
  if (!value) {
    return false;
  }

  return ['1', 'true', 'yes', 'on'].includes(value.toLowerCase());
}

function parseNumberFlag(value: string | undefined, fallback: number): number {
  if (!value) {
    return fallback;
  }

  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function getArgValue(args: string[], name: string): string | undefined {
  const prefix = `${name}=`;
  const inline = args.find((arg) => arg.startsWith(prefix));
  if (inline) {
    return inline.slice(prefix.length);
  }

  const index = args.indexOf(name);
  if (index >= 0) {
    return args[index + 1];
  }

  return undefined;
}

function hasArg(args: string[], name: string): boolean {
  return args.includes(name);
}

function parseManagedClientMode(value: string | undefined | null): ManagedClientMode | null {
  if (!value) {
    return null;
  }

  if (value === 'managed-client' || value === 'managed-client-mcp-ws') {
    return value;
  }

  return null;
}

function normalizeManagedClientToken(token: string | null | undefined): string | null {
  const trimmed = token?.trim();
  if (!trimmed) {
    return null;
  }

  return trimmed.replace(/^Bearer\s+/i, '').trim();
}

function normalizeOptionalString(value: string | null | undefined): string | null {
  const trimmed = value?.trim();
  return trimmed ? trimmed : null;
}

function getOrCreateManagedClientId(fileConfig: ManagedClientFileConfig): string {
  if (fileConfig.clientId?.trim()) {
    return fileConfig.clientId.trim();
  }

  const clientId = randomUUID();
  saveManagedClientFileConfig({ clientId });
  return clientId;
}

export function getManagedClientWorkspaceRoot(args = process.argv): string {
  const fileConfig = loadManagedClientFileConfig();
  const workspaceRoot =
    getArgValue(args, '--managed-client-workspace-root')
    ?? process.env.MANAGED_CLIENT_WORKSPACE_ROOT
    ?? fileConfig.workspaceRoot
    ?? getDefaultManagedClientWorkspaceRoot();

  return path.resolve(workspaceRoot);
}

export function getManagedClientRuntimeConfig(version: string, args = process.argv): ManagedClientRuntimeConfig {
  const fileConfig = loadManagedClientFileConfig();
  const explicitMode =
    parseManagedClientMode(getArgValue(args, '--managed-client-mode'))
    ?? parseManagedClientMode(process.env.MANAGED_CLIENT_MODE)
    ?? parseManagedClientMode(fileConfig.mode)
    ?? null;

  const wsManagedMode =
    explicitMode === 'managed-client-mcp-ws'
    || hasArg(args, '--enable-managed-client-mcp-ws')
    || hasArg(args, '--managed-client-mcp-ws-only');

  const pollingManagedMode =
    explicitMode === 'managed-client'
    || hasArg(args, '--enable-managed-client-runtime')
    || hasArg(args, '--managed-client-only')
    || parseBooleanFlag(process.env.ENABLE_MANAGED_CLIENT_RUNTIME)
    || fileConfig.enabled === true;

  const enabled = wsManagedMode || pollingManagedMode;
  const mode: ManagedClientMode = wsManagedMode ? 'managed-client-mcp-ws' : 'managed-client';
  const headless = hasArg(args, '--managed-client-only') || hasArg(args, '--managed-client-mcp-ws-only');
  const baseUrl =
    getArgValue(args, '--managed-client-base-url')
    ?? fileConfig.bootstrapBaseUrl
    ?? process.env.MANAGED_CLIENT_BASE_URL
    ?? fileConfig.baseUrl
    ?? null;
  const signinPageUrl =
    getArgValue(args, '--managed-client-signin-page-url')
    ?? process.env.MANAGED_CLIENT_SIGNIN_PAGE_URL
    ?? fileConfig.signinPageUrl
    ?? null;
  const tlsServername =
    getArgValue(args, '--managed-client-tls-servername')
    ?? process.env.MANAGED_CLIENT_TLS_SERVERNAME
    ?? fileConfig.tlsServername
    ?? null;
  const workspaceRoot = getManagedClientWorkspaceRoot(args);
  const token = normalizeManagedClientToken(
    getArgValue(args, '--managed-client-token') ?? process.env.MANAGED_CLIENT_BEARER_TOKEN ?? fileConfig.token ?? null,
  );
  const clientId = getArgValue(args, '--managed-client-id') ?? process.env.MANAGED_CLIENT_ID ?? getOrCreateManagedClientId(fileConfig);
  const clientName = getArgValue(args, '--managed-client-name') ?? process.env.MANAGED_CLIENT_NAME ?? fileConfig.clientName ?? os.hostname();
  const pollWaitSeconds = parseNumberFlag(
    getArgValue(args, '--managed-client-wait-seconds') ?? process.env.MANAGED_CLIENT_WAIT_SECONDS ?? String(fileConfig.pollWaitSeconds ?? ''),
    20,
  );
  const retryDelayMs = parseNumberFlag(
    getArgValue(args, '--managed-client-retry-ms') ?? process.env.MANAGED_CLIENT_RETRY_MS ?? String(fileConfig.retryDelayMs ?? ''),
    3000,
  );
  const mcpServers = parseManagedClientMcpServers(loadManagedClientMcpFileConfig());

  return {
    mode,
    enabled,
    headless,
    baseUrl: baseUrl ? baseUrl.replace(/\/+$/, '') : null,
    signinPageUrl: signinPageUrl ? signinPageUrl.replace(/\/+$/, '') : null,
    tlsServername: normalizeOptionalString(tlsServername),
    workspaceRoot,
    token,
    clientId,
    clientName,
    pollWaitSeconds,
    retryDelayMs,
    version,
    supportedCommands: ['run_command', 'read_file'],
    mcpServers,
  };
}