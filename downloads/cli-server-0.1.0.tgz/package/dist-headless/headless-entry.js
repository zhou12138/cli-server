"use strict";
/**
 * headless-entry.ts — 纯 Node.js 入口（无 Electron 依赖）
 *
 * 用法: node headless-entry.js [options]
 *   --enable-managed-client-mcp-ws    启用 WebSocket managed client
 *   --managed-client-mcp-ws-only      仅运行 managed client（无 HTTP server）
 *
 * 环境变量:
 *   XCLAW_NODE_DATA_DIR   数据目录（默认: .xclaw-node-data）
 *   DISPLAY               虚拟显示（Linux headless 用）
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const path = __importStar(require("node:path"));
const fs = __importStar(require("node:fs"));
const manager_1 = require("./session/manager");
const mcp_ws_runtime_1 = require("./managed-client/mcp-ws-runtime");
const config_1 = require("./managed-client/config");
const logger_1 = require("./audit/logger");
const logger_2 = require("./activity/logger");
const server_1 = require("./server");
// ========================
// 数据目录（替代 Electron 的 app.getPath）
// ========================
const ROOT_DIR = path.resolve(__dirname, '..');
const DATA_DIR = process.env.XCLAW_NODE_DATA_DIR || path.join(ROOT_DIR, '.xclaw-node-data');
fs.mkdirSync(DATA_DIR, { recursive: true });
// 设置全局数据目录供 logger 使用
process.env.XCLAW_NODE_DATA_DIR = DATA_DIR;
// ========================
// 初始化
// ========================
console.log('[headless] LandGod Headless Runtime starting...');
console.log(`[headless] Data dir: ${DATA_DIR}`);
console.log(`[headless] Root dir: ${ROOT_DIR}`);
// 初始化日志
logger_1.auditLogger.init();
logger_2.activityLogger.init();
// 事件监听
(0, server_1.onServerEvent)((event) => {
    // 在 headless 模式下仅打印关键事件
    if (event.type.includes('error') || event.type.includes('rejected')) {
        console.error(`[event] ${event.type}`, event.data ? JSON.stringify(event.data).substring(0, 200) : '');
    }
});
// ========================
// 启动 managed-client-mcp-ws
// ========================
const config = (0, config_1.getManagedClientRuntimeConfig)('0.1.0');
console.log(`[headless] Config:`, {
    enabled: config.enabled,
    mode: config.mode,
    baseUrl: config.baseUrl,
    hasToken: !!config.token,
});
if (!config.enabled || !config.baseUrl) {
    console.error('[headless] Managed client is not enabled or baseUrl is not set. Run `landgod config` first.');
    process.exit(1);
}
const sessionManager = new manager_1.SessionManager();
const runtime = new mcp_ws_runtime_1.ManagedClientMcpWsRuntime(config, sessionManager);
runtime.start().then(() => {
    console.log('[headless] Managed client runtime started successfully.');
}).catch((error) => {
    console.error('[headless] Failed to start runtime:', error instanceof Error ? error.message : String(error));
    process.exit(1);
});
// ========================
// 保持进程运行 + 优雅退出
// ========================
process.on('SIGINT', () => {
    console.log('[headless] Received SIGINT, shutting down...');
    runtime.stop();
    process.exit(0);
});
process.on('SIGTERM', () => {
    console.log('[headless] Received SIGTERM, shutting down...');
    runtime.stop();
    process.exit(0);
});
// 防止进程退出
setInterval(() => { }, 60000);
